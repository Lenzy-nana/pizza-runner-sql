-- Q1: How many pizzas were ordered?
SELECT COUNT(*) AS total_pizzas_ordered
FROM pizza_runner.customer_orders;